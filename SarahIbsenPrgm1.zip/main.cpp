/*
Graphics Pgm 1 for Sarah Ibsen
Class: CS 445

Major Variables:
----------------
- canvas_Width, canvas_Height: 600x600 pixels
- canvas_Name: Snowman and Snowflake
- running: A boolean flag that controls whether or not the animation is active.
- snowflakeY: The current Y-coordinate of the falling snowflake.
- snowflakeSpeed: The rate at which the snowflake falls
- frameTime: The delay (in milliseconds) between frames

Architecture Structure:
----------------------

This program uses frame-based animation, specifically using the glut timer function in updateSnowflake(int value).
The display_func draws the snowman and the snowflake their current position.
key_pressed function is used to start and stop the animation by pressing any key.
main function initializes the window and sets up the display function.

Data Structures:
---------------
No major data structures are used in this program! <3

Program Flow:
------------
1. Initialize OpenGL and create the window
2. Display function clears the screen, postredisplay redraws the screen
3. Timer function updates the snowflake's position
4. Keyboard input starts or the animation.

Extra Credit:
------------



*/

#include <GL/glew.h>
#include <GL/freeglut.h>
#include <stdio.h>
#include<iostream> // using this library to debug my problems
#include "OpenGL445Setup-2025.h"
// setting the global variables here : )
#define canvas_Width 600
#define canvas_Height 600
char canvas_Name[]= "Snowman and Snowflake";

bool running = false; // Flag to start animation
float snowflakeY = 600.0; // Initial Y position of snowflake
float snowflakeSpeed = 4.0; // Speed of snowflake falling, 3 =< x => 4
const int frameTime = 25;  // 25 ms for the snowflake to fall down the screen
float bottomCanvas = 55.0; // bottom of the canvas that the snowflake will stop at

// display_func contains all of the initial drawing commands. updateSnowflake contains
// the updated drawing of the snowflake per frame!
void display_func() {
    glClearColor(0.0, 0.0, 0.0, 1.0);  // Black background
    glClear(GL_COLOR_BUFFER_BIT);


    // Draw the snowman
    glColor3f(1.0, 1.0, 1.0);

    // Bottom square (150x150)
    glBegin(GL_LINES);
        glVertex3f(225.0, 0.0, 0.0);   glVertex3f(225.0,150.0,0.0);
        glVertex3f(225.0,150.0,0.0);   glVertex3f(375.0,150.0,0.0);
        glVertex3f(375.0,150.0,0.0);   glVertex3f(375.0,0.0,0.0);
        glVertex3f(375.0,0.0,0.0);     glVertex3f(225.0,0.0,0.0);
    glEnd();

    // Middle square (110x110)
    glBegin(GL_LINES);
        glVertex3f(245.0,150.0,0.0);   glVertex3f(245.0,260.0,0.0);
        glVertex3f(245.0,260.0,0.0);   glVertex3f(355.0,260.0,0.0);
        glVertex3f(355.0,260.0,0.0);   glVertex3f(355.0,150.0,0.0);
        glVertex3f(355.0,150.0,0.0);   glVertex3f(245.0,150.0,0.0);
    glEnd();

    // Top square (60x60)
    glBegin(GL_LINES);
        glVertex3f(270.0,260.0,0.0);   glVertex3f(270.0,320.0,0.0);
        glVertex3f(270.0,320.0,0.0);   glVertex3f(330.0,320.0,0.0);
        glVertex3f(330.0,320.0,0.0);   glVertex3f(330.0,260.0,0.0);
        glVertex3f(330.0,260.0,0.0);   glVertex3f(270.0,260.0,0.0);
    glEnd();

    // Draw the snowflake at its current position
   // glLineWidth(2.0);
    glBegin(GL_LINES);
        glVertex3f(70.0, snowflakeY, 0.0); // vertical line
        glVertex3f(70.0, snowflakeY - 60.0, 0.0);
        glVertex3f(40.0, snowflakeY - 30.0, 0.0); // horizontal line
        glVertex3f(100.0, snowflakeY - 30.0, 0.0);
        glVertex3f(40.0, snowflakeY, 0.0);// diagonal
        glVertex3f(100.0, snowflakeY - 60.0, 0.0);
    glEnd();

   glFlush();
}
/* I chose to use this type of animation because when we spoke about it in class, it seemed
like the best option. */
void updateSnowflake(int value) {
    if (running) {
        // Update snowflake's Y position
        snowflakeY -= snowflakeSpeed;

        if (snowflakeY <= bottomCanvas) {
            running = false;
            return;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(frameTime, updateSnowflake, 0);
}


// Keyboard function to start and stop animation
void keyPressed(unsigned char key, int x, int y) {
    if (key == 3) {  // ASCII for Ctrl+C
        exit(0);  // Exit the program
    } else if (!running) {
        running = true;
        //snowflakeY = 600.0;  // Reset snowflake position for restart
        glutTimerFunc(frameTime, updateSnowflake, 0);  // Start animation
    }
}


int main(int argc, char ** argv)
{   // print instructions to the screen
    printf("Click any key to begin animation.");
    glutInit(&argc, argv);
    my_setup(canvas_Width, canvas_Height, canvas_Name);

    glutDisplayFunc(display_func);
    glutKeyboardFunc(keyPressed); //registering the function

    glutMainLoop();
    return 0;
}


