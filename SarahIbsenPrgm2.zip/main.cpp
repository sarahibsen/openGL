/*
Graphics Pgm 2 for Sarah Ibsen
Class: CS 445


Architecture Structure:
----------------------
This program includes a snowman, with arms and a carrot nose, in a winter scene consisting of two snowflakes
continuously falling.
There are two snowflakes that fall from the top of the canvas once the user clicks their mouse.
The only way that the snowflakes stop falling is when the user closes the application.


Data Structures:
---------------
A keyboard event listener to implement a snowblower effect that nudges snowflakes right.
A mouse event listener starts the animation upon clicking.
createSnowmanList(): generates the display list for the snowman


Program Flow:
------------
display_func() clears the screen and sets the background color. It calls the snowman display list for rendering
it draws two snowflakes and displays the start message until the animation begins.
mouseClicked() is where the event listener lives, the left or right click starts the animation, and the
message disappears once clicked. It calls glutTimerFunc() to start the snowflake animation.
updateSnowFlake() moves the first snowflake downward, and moves the snowflake right every 2 units. Once the
snowflake is halfway down, the second snowflake begins to fall as well. Their respective position resets when they reach
the bottom of the canvas.
keyboardFunc() is activated when the user hits the 'b' key, this simulates a snowblower off the screen at the
specific range of 200 - 400 units from the bottom of the screen.
main() initializes the OpenGL settings, it registers the display, mouse, and keyboard handlers.


Differences in Code Structure from Pgrm 1:
------------------------------------------
Added the arms and carrot nose for the snowman.
Added a display list to render the snowman more effectively by saving the drawing instead of drawing each frame.
Added a mouse event handler that controls the animation instead of using the key event handler.
Added the snowblower effect (off the screen)
Added an additional snowflake, and calculated the snowflake angles using the cmath library (last program my calculations were off)

Extra Credit:
------------
Extra credit assigned was to create arms and an orange carrot nose for the snowman. I put this design
in the createSnowmanList() because that is where the creation of the display list is made for
populated the snowman (instead of drawing it each frame of animation)!


*/

#include <GL/glew.h>
#include <GL/freeglut.h>
#include <stdio.h>
#include<iostream> // using this library to debug my problems
#include "OpenGL445Setup-2025.h"
#include <cmath> // for help on creating my snowflake
// setting the global variables here : )
#define canvas_Width 600
#define canvas_Height 600
#define DEG2RAD (M_PI / 180.0) // radians to use for the snowflake
char canvas_Name[]= "Snowman and Snowflake";

bool secondSnowflakeVisible = false;
bool running = false; // Flag to start animation
float snowflake1Y = 600.0, snowflake2Y = 600.0; // initial Y positions for snowflake
float snowflake1X = 60.0, snowflake2X = 160.0; // initial X positions for snowflake
float snowflakeSpeed = 4.0; // speed of snowflake falling, 3 =< x => 4
const int frameTime = 20;  // 20 ms for the snowflake to fall down the screen
float bottomCanvas = 20.0; // bottom of the canvas that the snowflake will stop at
bool moveRight = false;  // toggle movement for every other frame
int snowmanList; // display list ID
bool showMessage = true; // Boolean to hide message after display click

void createSnowmanList() {
    // begin of display list gen

    snowmanList = glGenLists(1);
    glNewList(snowmanList, GL_COMPILE);

    glColor3f(1.0, 1.0, 1.0); // White color for the snowman

    // **Bottom square (150x150)**
    glBegin(GL_LINES);
        glVertex3f(205.0, 0.0, 0.0); glVertex3f(205.0, 150.0, 0.0);
        glVertex3f(205.0, 150.0, 0.0); glVertex3f(355.0, 150.0, 0.0);
        glVertex3f(355.0, 150.0, 0.0); glVertex3f(355.0, 0.0, 0.0);
        glVertex3f(355.0, 0.0, 0.0); glVertex3f(205.0, 0.0, 0.0);
    glEnd();

    // **Middle square (110x110)**
    glBegin(GL_LINES);
        glVertex3f(225.0, 150.0, 0.0); glVertex3f(225.0, 260.0, 0.0);
        glVertex3f(225.0, 260.0, 0.0); glVertex3f(335.0, 260.0, 0.0);
        glVertex3f(335.0, 260.0, 0.0); glVertex3f(335.0, 150.0, 0.0);
        glVertex3f(335.0, 150.0, 0.0); glVertex3f(225.0, 150.0, 0.0);
    glEnd();

    // **Top square (60x60)**
    glBegin(GL_LINES);
        glVertex3f(250.0, 260.0, 0.0); glVertex3f(250.0, 320.0, 0.0);
        glVertex3f(250.0, 320.0, 0.0); glVertex3f(310.0, 320.0, 0.0);
        glVertex3f(310.0, 320.0, 0.0); glVertex3f(310.0, 260.0, 0.0);
        glVertex3f(310.0, 260.0, 0.0); glVertex3f(250.0, 260.0, 0.0);
    glEnd();

    // start of the carrot and arms
    glColor3f(1.0, 0.5, 0.0); // Orange color for the carrot
    glBegin(GL_LINES);
    // bottom portion of the triangle for the nose
    glVertex3f(250.0, 300.0, 0.0); glVertex3f(230.0, 295.0, 0.0);
    glVertex3f(230.0, 295.0, 0.0); glVertex3f(250.0, 285.0, 0.0);
    // top portion of the triangle
    glVertex3f(250.0, 285.0, 0.0);



    glEnd();

    // Stick Arms
    glColor3f(0.4, 0.2, 0.0); // Brown color for arms
    glBegin(GL_LINES);
    // Left arm
    glVertex3f(225.0, 210.0, 0.0);
    glVertex3f(185.0, 210.0, 0.0);

    // Right arm
    glVertex3f(335.0, 210.0, 0.0);
    glVertex3f(375.0, 210.0, 0.0);

    // little bittie fingers left side first then right side
    glVertex3f(185.0, 210.0, 0.0); // Hand endpoint
    glVertex3f(175.0, 215.0, 0.0);

    glVertex3f(185.0, 210.0, 0.0);
    glVertex3f(175.0, 205.0, 0.0);

    glVertex3f(375.0, 210.0, 0.0); // right side fingers
    glVertex3f(385.0, 215.0, 0.0);

    glVertex3f(375.0, 210.0, 0.0);
    glVertex3f(385.0, 205.0, 0.0);

    glEnd();

    glEndList(); // end of the display list
}

void drawSnowflake(float x, float y) {
    // reset of the color
    glColor3f(1.0, 1.0, 1.0); // white
    // convert 60.0 to radians
    float angleRad = 60.0 * DEG2RAD;

    glBegin(GL_LINES);
        // Horizontal Line
        glVertex3f(x - 30.0, y, 0.0);
        glVertex3f(x + 30.0, y, 0.0);

        // Bottom Left to Top Right
        glVertex3f(x - 30.0 * cos(angleRad), y - 30.0 * sin(angleRad), 0.0);
        glVertex3f(x + 30.0 * cos(angleRad), y + 30.0 * sin(angleRad), 0.0);

        // Top Left to Bottom Right
        glVertex3f(x - 30.0 * cos(angleRad), y + 30.0 * sin(angleRad), 0.0);
        glVertex3f(x + 30.0 * cos(angleRad), y - 30.0 * sin(angleRad), 0.0);
    glEnd();
}

// Bitmap String
void writeBitmapString(void *font, char *string)
{
	char *c;
	for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

// display_func contains all of the initial drawing commands. updateSnowflake contains
// the updated drawing of the snowflake per frame!
void display_func() {
    glClearColor(0.29,0.29,0.29, 1.0); // charcoal gray
    glClear(GL_COLOR_BUFFER_BIT);

    // print to the screen "Any Mouse Click Will Start"

    // Draw the snowman and snowflake with this color <3
    glColor3f(1.0, 1.0, 1.0);
    // Draw the snowman
    glCallList(snowmanList);

    // the first snowflake at its current position
    drawSnowflake(snowflake1X, snowflake1Y); // using dynamic positions so that the snowflakes can move

    // second snowflake 100 units from the left edge
    drawSnowflake(snowflake2X, snowflake2Y);

    // draw the "any mouse click will start" but after the mouse click, the writing will disappear
    if (showMessage) {
        glRasterPos3f(180.0, 300.0, 0.0);
        writeBitmapString(GLUT_BITMAP_HELVETICA_18, "Any Mouse Click Will Start");
    }


   glFlush();
}

void updateSnowflake(int value) {
    if (running) {
        // Move downward
        snowflake1Y -= snowflakeSpeed;

        // Alternate rightward movement
        if (moveRight) {
            snowflake1X += 2.0;
        }
        moveRight = !moveRight;

        // Activate second snowflake when first reaches halfway
        if (snowflake1Y <= 300.0) {
            secondSnowflakeVisible = true;
        }

        if (secondSnowflakeVisible) {
            snowflake2Y -= snowflakeSpeed;
            if (moveRight) {
                snowflake2X += 2.0;
            }
        }

        // Reset when reaching bottom
        if (snowflake1Y <= bottomCanvas) {
            snowflake1Y = 600.0;
            snowflake1X = 60.0;
            moveRight = false;  // Reset right movement toggle
        }
        if (snowflake2Y <= bottomCanvas) {
            snowflake2Y = 600.0;
            snowflake2X = 160.0;
        }
    glutPostRedisplay();
    glutTimerFunc(frameTime, updateSnowflake, 0); // using glutTimerFunc because this gives us more
    // control on the speed of the snowflake falling, also gives a 'smooth' look of animation
} }


void mouseClicked(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && !running) {
        running = true;
        showMessage = false; // message should disappear
        glutTimerFunc(frameTime, updateSnowflake, 0); // Start animation
    }
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && !running){
        running = true;
        showMessage = false; // message should disappear
        glutTimerFunc(frameTime, updateSnowflake, 0); // start of the animation for the right button click
    }
}

// snowblower Effect: Moves snowflakes right when 'b' key is pressed
void keyboardFunc(unsigned char key, int x, int y) {
    if (key == 98) {
            // every time snowflake is 200 - 400 units from the bottom of the screen
            // and a user clicks the 'b' key, displace snowflake
        if (snowflake1Y >= 200 && snowflake1Y <= 400) {
            snowflake1X += 4.0;
        }
        if (snowflake2Y >= 200 && snowflake2Y <= 400) {
            snowflake2X += 4.0;
        }
        glutPostRedisplay();
    }
}

int main(int argc, char ** argv)
{


    glutInit(&argc, argv);
    my_setup(canvas_Width, canvas_Height, canvas_Name);
    glewInit(); // Initialize GLEW before using OpenGL functions

    createSnowmanList();

    glutDisplayFunc(display_func);
    glutMouseFunc(mouseClicked); // mouse handler to start animation
    glutKeyboardFunc(keyboardFunc); // keyboard handler for the off-screen snowblower


    glutMainLoop();
    return 0;
}

