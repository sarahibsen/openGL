/*
Graphics Prgm 3 for Sarah Ibsen
Class: CS 445


Architecture Structure:
----------------------
GLUT generation of a game that contains a diamond shape spacecraft, that is drawn in the drawDiamond()
function, and is called upon in the display_func(), when the display_func() calls the display list.
The display list is initialized in the drawDiamond() function.
The keyboard press is handled in the keyboard event handler, located in void keyboardFunc. It contains
key press logic for 'I', 'M', 'J', 'H', and 'U'. The 'I' and 'M' are associated with different values of gravity
and the start of the animation. The 'J', 'H', and 'U' keys are associated with controlling the movement of the
diamond spacecraft.
The timer function manages the animation logic of the diamond's movement and descent. It applies
the diamonds velocity, based on the 'M' or 'I' choice from the user. This is all in timer function.
The game also includes a fuel check on the top right hand of the screen, when the user clicks the 'u' key
the fuel is subtracted 5, when the user clicks 'j' or 'h' the user loses 1 fuel point each. The keyboard event handler
is located in the keyboardFunc definition, and the fuel updated display is located in display_func.



*/

#include <GL/glew.h>
#include <GL/freeglut.h>
#include <stdio.h>
#include<iostream> // using this library to debug my problems
#include "OpenGL445Setup-2025.h"
#include <cmath> // for help on creating my snowflake
// setting the global variables here : )
#define canvas_Width 800
#define canvas_Height 600

char canvas_Name[]= "Diamond Drop";

float diamondY = canvas_Height; //starting position 'Y' for the diamond - should be the start of the canvas
float diamondX = canvas_Width / 2.0f;
float velocity = 0.0; // init velocity
float gravity = 0.0;
const int frameTime = 0; // need to change
//float bottomCanvas = 7.0; // bottom of the canvas
bool isAnimating = false;
bool showMessage = true; // display the starting message
int diamond;

int fuel = 200; //
bool gameWon = false;

// landing zone
float landingZoneX =  10.0f;     // leftmost point
float landingZoneWidth = 40.0f; // Width of chevron
float landingZoneHeight = 10.0f; // Height of chevron


void drawDiamond(){

    diamond = glGenLists(1);
    glNewList(diamond, GL_COMPILE);

    glColor3f(0.0f, 0.47f, 0.78f); // UAH Blue

    // Scale the octahedron to make each line segment roughly 25 units
    glPushMatrix();
    glScalef(17.67f, 17.67f, 17.67f); // Scaling to desired size
    glutWireOctahedron();           // Draw the wireframe octahedron
    glPopMatrix();                  // 17.35 comes in somewhere ??

    glEndList();
}



// Bitmap String
void writeBitmapString(void *font, char *string)
{
	char *c;
	for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

// display_func contains all of the initial drawing commands
void display_func() {
    glClearColor(1.0, 1.0, 0.0, 1.0); // yellow background
    glClear(GL_COLOR_BUFFER_BIT);

    // draw the red line
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
    glVertex2f(0.0, 7.0);
    glVertex2f(canvas_Width, 7.0); // 7.0 pixels from the bottom of the canvas
    glEnd();

    // Draw Landing Zone (Black Rectangle)
    glColor3f(0.0, 0.0, 0.0); // Black Rectangle
    glBegin(GL_POLYGON);
    glVertex2f(10.0, 0.0);
    glVertex2f(40.0, 0.0);
    glVertex2f(40.0, 10.0);
    glVertex2f(10.0, 10.0);
    glEnd();

    // Draw Chevron Cut-Out (Yellow Chevron Overlay-ish)
    glColor3f(1.0, 1.0, 0.0); // Yellow Chevron
    glBegin(GL_TRIANGLES);
    glVertex2f(25.0, 7.0);  // Point touches the red line
    glVertex2f(20.0, 10.0); // Left top corner
    glVertex2f(30.0, 10.0); // Right top corner
    glEnd();


    glPushMatrix();
    glTranslatef(diamondX, diamondY, -50.0f);

    // Draw the diamond
    glCallList(diamond);
    glPopMatrix();

    // Display Fuel
    glColor3f(0.0, 0.0, 0.0);  // Black text
    char fuelDisplay[20];
    snprintf(fuelDisplay, sizeof(fuelDisplay), "Fuel: %d", fuel);
    glRasterPos3f(650.0, 570.0, 0.0);  // position the text
    writeBitmapString(GLUT_BITMAP_HELVETICA_18, fuelDisplay);

    // Display "YOU WIN" message
    if (gameWon) {
        glColor3f(0.0, 0.0, 0.0);
        glRasterPos3f(300.0, 300.0, 0.0);
        glutBitmapString(GLUT_BITMAP_HELVETICA_18, (const unsigned char *)"YOU WIN!");
    }

    // draw the "any mouse click will start" but after the mouse click, the writing will disappear
    if (showMessage) {
        glColor3f(0.0,0.0,0.0); // Black
        glRasterPos3f(180.0, 300.0, 0.0);
        writeBitmapString(GLUT_BITMAP_HELVETICA_18, "Press M or I to Start");
    }


   glFlush();
}

void timer(int value){
    float deltaTime = 0.05;
    if (isAnimating) {
        velocity += gravity * deltaTime;      // Apply gravity
        diamondY -= velocity;     // Update position
        //fuel--;
        glutPostRedisplay();
    }
    else{
        isAnimating = false;
    }

    if (diamondY - 18.0f <= 7.0f) { // had to change because of the scaling
        diamondY = 7.0f + 18.0f; // making sure that the diamond is reaching the red line
        velocity = 0.0f;
        isAnimating = false;
    }


        // Win condition detection
    if (diamondX >= landingZoneX && diamondX <= landingZoneX + landingZoneWidth &&
        diamondY <= 32.0f) {
        gameWon = true;
        isAnimating = false;
    }

   // glutPostRedisplay();

    glutTimerFunc(50, timer, 0);
}

void keyboardFunc(unsigned char key, int x, int y) {
    if (key == 'm' || key == 'M') {
        gravity = 5.3;  // Moon's gravity
        isAnimating = true;
        showMessage = false;
        glutPostRedisplay();
    }

    if (key == 'i' || key == 'I') {
        gravity = 5.9;  // Io's gravity
        isAnimating = true;
        showMessage = false;
        glutPostRedisplay();
    }

    if (key == 'h' || key == 'H') {
        if (diamondX - 4.0f > 0) { // Prevent moving off-screen
        diamondX -= 4.0f;
        fuel--;
        glutPostRedisplay();
    }
}
    if (key == 'j' || key == 'J') {
        if (diamondX + 4.0f < canvas_Width) { // Prevent moving off-screen
            diamondX += 4.0f;
            fuel--;
            glutPostRedisplay();
        }
    }
    if (key == 'u' || key == 'U') {
        if (diamondY + 5.0f < canvas_Height) { // Prevent moving off-screen
            diamondY += 5.0f;
            fuel-= 5; // every time the diamond moves 'up' the fuel decreases by 5
        if (fuel <= 0.0f) {
            fuel = 0.0f;     // Prevent negative fuel
           // diamondY = 0.0f; // Diamond stops moving when fuel is depleted
        }

        }
    }

}


int main(int argc, char ** argv)
{
    glutInit(&argc, argv);
    my_setup(canvas_Width, canvas_Height, canvas_Name);
    glewInit(); // Initialize GLEW before using OpenGL functions

    drawDiamond();
    glutDisplayFunc(display_func);
    glutKeyboardFunc(keyboardFunc);
    glutTimerFunc(50, timer, 0); // start the timer animation


    glutMainLoop();
    return 0;
}

